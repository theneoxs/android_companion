package com.example.testapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.example.testapp.Common.Common;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

import static android.view.View.INVISIBLE;
import static android.view.View.VISIBLE;

public class ReminderList extends Activity {
    private AlertDialog dialog;
    //верх
    MaterialToolbar mtb;
    //поле
    CoordinatorLayout coordLayout;
    //низ
    BottomNavigationView bnv;
    LinearLayout mainFill;

    List<EditText> eText = new ArrayList<>();
    int textCount = 5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reminder);

        coordLayout = findViewById(R.id.coordLayout);
        mtb = findViewById(R.id.topAppBar);
        bnv = findViewById(R.id.navigation);
        //бок
        final NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        mainFill = findViewById(R.id.mainFill);

        eText.add((EditText)findViewById(R.id.text1));
        eText.add((EditText)findViewById(R.id.text2));
        eText.add((EditText)findViewById(R.id.text3));
        eText.add((EditText)findViewById(R.id.text4));
        eText.add((EditText)findViewById(R.id.text5));
        for (int i = 0; i < Common.savedReminder.size(); i++){
            eText.get(i).setText(Common.savedReminder.get(i));
        }
        mtb.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigationView.setVisibility(VISIBLE);
            }
        });
        mtb.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()){
                    case R.id.save:
                        Common.savedReminder.clear();
                        String text = "";
                        for (int i = 0; i < textCount; i++){
                            text = eText.get(i).getText().toString();
                            if (!text.equals("")) {
                                Common.savedReminder.add(text);
                            }
                        }
                        Snackbar.make((View)findViewById(R.id.mainFill), "Save!", Snackbar.LENGTH_LONG).show();
                        return true;
                }
                return false;
            }
        });
        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    // This method will trigger on item Click of navigation menu
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        Intent intent;
                        switch (menuItem.getItemId()){
                            case R.id.nav_home:
                                intent = new Intent(ReminderList.this, MainActivity.class);
                                startActivityForResult(intent, RESULT_OK);
                                return true;
                            case R.id.nav_motlist:
                                intent = new Intent(ReminderList.this, MotivationList.class);
                                startActivityForResult(intent, RESULT_OK);
                                return true;
                            case R.id.nav_agglist:
                                intent = new Intent(ReminderList.this, AggressiveList.class);
                                startActivityForResult(intent, RESULT_OK);
                                return true;
                            case R.id.nav_exit:
                                finish();
                                return true;
                            case R.id.nav_remlist:
                                navigationView.setVisibility(INVISIBLE);
                                return true;
                        }
                        navigationView.setVisibility(INVISIBLE);
                        return false;
                    }
                });
        coordLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigationView.setVisibility(INVISIBLE);
            }
        });

    }
}
