package com.example.testapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.testapp.Common.Common;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class FloatingWindowGFG extends Service {
    private ViewGroup floatView;
    private int LAYOUT_TYPE;
    private WindowManager.LayoutParams floatWindowLayoutParam;
    private WindowManager windowManager;

    ImageView img;
    TextView tv;
    List<String> masText= new ArrayList<>();

    private int access = 0;
    public static Handler UIHandler;
    static
    {
        UIHandler = new Handler(Looper.getMainLooper());
    }
    public static void runOnUI(Runnable runnable) {
        UIHandler.post(runnable);
    }

    int width = 0;
    int height = 0;
    // As FloatingWindowGFG inherits Service class,
    // it actually overrides the onBind method
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void onCreate() {
        super.onCreate();
        DisplayMetrics metrics = getApplicationContext().getResources().getDisplayMetrics();
        width = metrics.widthPixels;
        height = metrics.heightPixels;
        System.out.println(width);
        System.out.println(height);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        LayoutInflater inflater = (LayoutInflater) getBaseContext().getSystemService(LAYOUT_INFLATER_SERVICE);

        floatView = (ViewGroup) inflater.inflate(R.layout.floating_layout, null);

        img = floatView.findViewById(R.id.imageView2);
        tv = floatView.findViewById(R.id.textView);
        tv.setText("");
        tv.setBackgroundColor(Color.TRANSPARENT);
        left = 101;
        img.setBackgroundResource(Common.back);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            LAYOUT_TYPE = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            LAYOUT_TYPE = WindowManager.LayoutParams.TYPE_TOAST;
        }

        floatWindowLayoutParam = new WindowManager.LayoutParams(
                300,
                100,
                LAYOUT_TYPE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );

        floatWindowLayoutParam.gravity = Gravity.LEFT | Gravity.TOP;

        floatWindowLayoutParam.x = 0;
        floatWindowLayoutParam.y = 0;

        windowManager.addView(floatView, floatWindowLayoutParam);

        new Thread() {
            public void run(){
                while (true){
                    try {
                        FloatingWindowGFG.runOnUI(run1);
                        Thread.sleep(10);
                    } catch (InterruptedException e){
                        e.printStackTrace();
                    }

                }
            }
        }.start();

        new Thread() {
            public void run(){
                while (true){
                    try {
                        FloatingWindowGFG.runOnUI(run2);
                        Thread.sleep(5000);
                        FloatingWindowGFG.runOnUI(run3);
                        Thread.sleep(20000);
                    } catch (InterruptedException e){
                        e.printStackTrace();
                    }

                }
            }
        }.start();

        floatView.setOnTouchListener(new View.OnTouchListener() {
            final WindowManager.LayoutParams floatWindowLayoutUpdateParam = floatWindowLayoutParam;
            double x;
            double y;
            double px;
            double py;

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {
                    // When the window will be touched,
                    // the x and y position of that position
                    // will be retrieved
                    case MotionEvent.ACTION_DOWN:
                        x = floatWindowLayoutUpdateParam.x;
                        y = floatWindowLayoutUpdateParam.y;

                        // returns the original raw X
                        // coordinate of this event
                        px = event.getRawX();

                        // returns the original raw Y
                        // coordinate of this event
                        py = event.getRawY();
                        access = 1;
                        break;
                    // When the window will be dragged around,
                    // it will update the x, y of the Window Layout Parameter
                    case MotionEvent.ACTION_MOVE:
                        floatWindowLayoutUpdateParam.x = (int) ((x + event.getRawX()) - px);
                        floatWindowLayoutUpdateParam.y = (int) ((y + event.getRawY()) - py);

                        // updated parameter is applied to the WindowManager
                        windowManager.updateViewLayout(floatView, floatWindowLayoutUpdateParam);
                        break;
                    case MotionEvent.ACTION_UP:
                        access = 0;
                        break;
                }
                return false;
            }
        });

        if (Common.checkAggressive == 1){
            masText.addAll(Common.savedAggressive);
        }
        if (Common.checkReminder == 1){
            masText.addAll(Common.savedReminder);
        }
        if (Common.checkMotivation == 1){
            masText.addAll(Common.savedMotivation);
        }
    }

    // It is called when stopService()
    // method is called in MainActivity
    @Override
    public void onDestroy() {
        super.onDestroy();
        stopSelf();
        // Window is removed from the screen
        windowManager.removeView(floatView);
    }

    double x;
    double y;
    double px = 1;
    double py = 1;
    int left = 101;
    Runnable run1 = new Runnable()
    {
        public void run() {
            if (access == 0) {
                WindowManager.LayoutParams floatWindowLayoutUpdateParam = floatWindowLayoutParam;

                x = floatWindowLayoutUpdateParam.x;
                y = floatWindowLayoutUpdateParam.y;

                floatWindowLayoutUpdateParam.x = (int) (x + px);
                floatWindowLayoutUpdateParam.y = (int) (y + py);

                if (x > width - left || x < 0) {
                    px *= -1;
                    floatWindowLayoutUpdateParam.x = (int) (x + px);
                }
                if (y > height - 200 || y < 0) {
                    py *= -1;
                    floatWindowLayoutUpdateParam.y = (int) (y + py);
                }
                try {
                    windowManager.updateViewLayout(floatView, floatWindowLayoutUpdateParam);
                }
                catch (Exception e){
                    stopSelf();
                }
            }
        }
    };
    Runnable run2 = new Runnable()
    {
        @SuppressLint("ResourceAsColor")
        public void run() {
            String str = "";
            Random random = new Random();
            if (masText.size() != 0) {
                int i = random.nextInt(masText.size());
                str = masText.get(i);
                tv.setBackgroundColor(Color.WHITE);
            }
            tv.setText(str);
            left = 301;
        }
    };
    Runnable run3 = new Runnable()
    {
        public void run() {
            tv.setText("");
            tv.setBackgroundColor(Color.TRANSPARENT);
            left = 101;
        }
    };
}