package com.example.testapp;

import android.app.ActivityManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.widget.NestedScrollView;
import androidx.drawerlayout.widget.DrawerLayout;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.testapp.Common.Common;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

import static com.google.android.material.bottomnavigation.BottomNavigationView.*;

public class MainActivity extends AppCompatActivity {

    // The reference variables for the
    // Button, AlertDialog, EditText
    // classes are created
    // Ссылочные переменные для
    // Кнопка, AlertDialog, EditText
    // классы созданы
    private AlertDialog dialog;
    MaterialToolbar mtb;
    CoordinatorLayout nsv;
    BottomNavigationView bnv;
    LinearLayout skin;
    LinearLayout setting;
    LinearLayout inform;

    CheckBox motCB = null;
    CheckBox aggCB = null;
    CheckBox remCB = null;
    CheckBox sabCB = null;
    CheckBox weaCB = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        creadeStartData();

        nsv = findViewById(R.id.nsv);
        mtb = findViewById(R.id.topAppBar);
        bnv = findViewById(R.id.navigation);
        final NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        skin = findViewById(R.id.skinlist);
        setting = findViewById(R.id.setlist);
        inform = findViewById(R.id.infolist);

        motCB = findViewById(R.id.motivBox);
        aggCB = findViewById(R.id.aggressiveBox);
        remCB = findViewById(R.id.remindBox);
        sabCB = findViewById(R.id.sabotBox);
        weaCB = findViewById(R.id.weatherBox);
        if (Common.checkMotivation == 1){
            motCB.setChecked(true);
        }
        if (Common.checkReminder == 1){
            remCB.setChecked(true);
        }
        if (Common.checkAggressive == 1){
            aggCB.setChecked(true);
        }
        sabCB.setEnabled(false);
        weaCB.setEnabled(false);

        RelativeLayout benis = findViewById(R.id.benis);
        RelativeLayout vortex = findViewById(R.id.vortex);

        setting.setVisibility(VISIBLE);
        skin.setVisibility(INVISIBLE);
        inform.setVisibility(INVISIBLE);
        benis.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView text = findViewById(R.id.list_title_benis);
                mtb.setTitle(text.getText());
                Common.back = R.drawable.benis;
            }
        });
        vortex.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView text = findViewById(R.id.list_title_vortex);
                mtb.setTitle(text.getText());
                Common.back = R.drawable.vortex;
            }
        });
        bnv.setOnNavigationItemSelectedListener(new OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.page_1:
                        setting.setVisibility(VISIBLE);
                        skin.setVisibility(INVISIBLE);
                        inform.setVisibility(INVISIBLE);
                        if (navigationView.getVisibility()==VISIBLE){
                            navigationView.setVisibility(INVISIBLE);
                        }
                        return true;
                    case R.id.page_2:
                        setting.setVisibility(INVISIBLE);
                        skin.setVisibility(VISIBLE);
                        inform.setVisibility(INVISIBLE);
                        if (navigationView.getVisibility()==VISIBLE){
                            navigationView.setVisibility(INVISIBLE);
                        }
                        return true;
                    case R.id.page_3:
                        setting.setVisibility(INVISIBLE);
                        skin.setVisibility(INVISIBLE);
                        inform.setVisibility(VISIBLE);
                        if (navigationView.getVisibility()==VISIBLE){
                            navigationView.setVisibility(INVISIBLE);
                        }
                        return true;
                }
                return false;
            }
        });

        if (isMyServiceRunning()) {
            stopService(new Intent(MainActivity.this, FloatingWindowGFG.class));
        }

        mtb.setNavigationOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("Work!");
                navigationView.setVisibility(VISIBLE);
            }
        });
        mtb.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()){
                    case R.id.favorite:
                        if (checkOverlayDisplayPermission()) {
                            saveSettings();
                            startService(new Intent(MainActivity.this, FloatingWindowGFG.class));
                            finish();
                        } else {
                            requestOverlayDisplayPermission();
                        }
                        return true;
                }
                return false;
            }
        });
        /*nsv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                navigationView.setVisibility(INVISIBLE);
            }
        });*/
        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    // This method will trigger on item Click of navigation menu
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        Intent intent;
                        switch (menuItem.getItemId()) {
                            case R.id.nav_motlist:
                                saveSettings();
                                intent = new Intent(MainActivity.this, MotivationList.class);
                                startActivityForResult(intent, RESULT_OK);
                                return true;
                            case R.id.nav_agglist:
                                saveSettings();
                                intent = new Intent(MainActivity.this, AggressiveList.class);
                                startActivityForResult(intent, RESULT_OK);
                                return true;
                            case R.id.nav_remlist:
                                saveSettings();
                                intent = new Intent(MainActivity.this, ReminderList.class);
                                startActivityForResult(intent, RESULT_OK);
                                return true;
                            case R.id.nav_exit:
                                finish();
                                return true;
                            case R.id.nav_home:
                                navigationView.setVisibility(INVISIBLE);
                                return true;
                        }
                        return false;
                    }
                });

    }

    private boolean isMyServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);

        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (FloatingWindowGFG.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    private void requestOverlayDisplayPermission() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setCancelable(true);

        builder.setTitle("Screen Overlay Permission Needed");

        builder.setMessage("Enable 'Display over other apps' from System Settings.");

        builder.setPositiveButton("Open Settings", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, RESULT_OK);
            }
        });
        dialog = builder.create();
        dialog.show();
    }

    private boolean checkOverlayDisplayPermission() {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    }

    public void saveSettings(){
        if (motCB.isChecked()){
            Common.checkMotivation = 1;
        }
        else{
            Common.checkMotivation = 0;
        }

        if (remCB.isChecked()){
            Common.checkReminder = 1;
        }
        else{
            Common.checkReminder = 0;
        }

        if (aggCB.isChecked()){
            Common.checkAggressive = 1;
        }
        else{
            Common.checkAggressive = 0;
        }
    }

    public void creadeStartData(){
        Common.savedMotivation.add("Ты сможешь всё!");
        Common.savedMotivation.add("Сложности - верный путь!");
        Common.savedMotivation.add("Всё имеет смысл!");

        Common.savedAggressive.add("Только лох не может ничего сделать");
        Common.savedAggressive.add("Неудачники опускают руки");
    }
}