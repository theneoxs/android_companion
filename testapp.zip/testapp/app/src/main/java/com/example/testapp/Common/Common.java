package com.example.testapp.Common;

import com.example.testapp.R;

import java.util.ArrayList;
import java.util.List;

public class Common {
    public static int back = R.drawable.benis;
    public static List<String> savedMotivation = new ArrayList<>();
    public static List<String> savedAggressive = new ArrayList<>();
    public static List<String> savedReminder = new ArrayList<>();
    public static int checkMotivation = 1;
    public static int checkAggressive = 1;
    public static int checkReminder = 1;

}